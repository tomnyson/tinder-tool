// Tab switching
document.querySelectorAll('.tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
    tab.classList.add('active');
    document.getElementById(`${tab.dataset.tab}-panel`).classList.add('active');
  });
});

// Elements - Gamepad
const startBtn = document.getElementById('startBtn');
const stopBtn = document.getElementById('stopBtn');
const clickCountInput = document.getElementById('clickCount');
const minDelayInput = document.getElementById('minDelay');
const maxDelayInput = document.getElementById('maxDelay');

// Elements - Message
const startMsgBtn = document.getElementById('startMsgBtn');
const stopMsgBtn = document.getElementById('stopMsgBtn');
const messageTextInput = document.getElementById('messageText');
const messageCountInput = document.getElementById('messageCount');
const msgMinDelayInput = document.getElementById('msgMinDelay');
const msgMaxDelayInput = document.getElementById('msgMaxDelay');
const randomQuoteCheckbox = document.getElementById('randomQuote');
const quotesListInput = document.getElementById('quotesList');
const singleMessageGroup = document.getElementById('singleMessageGroup');
const quotesGroup = document.getElementById('quotesGroup');
const sendModeOptions = document.querySelectorAll('.send-mode-option');
const activeMessageSourceEl = document.getElementById('activeMessageSource');
const aiBulkNoteEl = document.getElementById('aiBulkNote');
const timeBasedQuotesCheckbox = document.getElementById('timeBasedQuotes');
const singleQuotesGroup = document.getElementById('singleQuotesGroup');
const timeBasedQuotesGroup = document.getElementById('timeBasedQuotesGroup');
const morningQuotesInput = document.getElementById('morningQuotes');
const noonQuotesInput = document.getElementById('noonQuotes');
const eveningQuotesInput = document.getElementById('eveningQuotes');
const currentTimeSlotEl = document.getElementById('currentTimeSlot');
const MESSAGE_DRAFT_KEY = 'messageDraft';
const MESSAGE_DRAFT_FALLBACK_KEY = 'tinder_ext_messageDraft';

// AI mode toggle in Message panel
let selectedAIMode = 'fixed';

// Model selector elements
const modelSelect = document.getElementById('modelSelect');
const customModelInput = document.getElementById('customModelInput');

// AI panel elements (declared early for saveAIConfig)
const apiKeyInput = document.getElementById('apiKeyInput');
const systemPromptInput = document.getElementById('systemPromptInput');
const userPromptInput = document.getElementById('userPromptInput');
const testAiGenerateBtn = document.getElementById('testAiGenerateBtn');
const aiGeneratingEl = document.getElementById('aiGenerating');
const aiPreviewEl = document.getElementById('aiPreview');
const aiPreviewTextEl = document.getElementById('aiPreviewText');

// Toggle custom model input visibility
if (modelSelect) {
  modelSelect.addEventListener('change', () => {
    if (customModelInput) {
      customModelInput.style.display = modelSelect.value === 'custom' ? 'block' : 'none';
    }
    // Auto-save on change
    saveAIConfig();
  });
}

// Auto-save AI config helper
async function saveAIConfig() {
  try {
    const modelValue = modelSelect && modelSelect.value === 'custom'
      ? (customModelInput ? customModelInput.value.trim() : '')
      : (modelSelect ? modelSelect.value : 'google/gemini-2.5-flash');
    await chrome.storage.local.set({
      openRouterApiKey: apiKeyInput.value.trim(),
      aiSystemPrompt: systemPromptInput.value.trim(),
      aiUserPrompt: userPromptInput.value.trim(),
      aiModel: modelValue
    });
  } catch (e) {
    try {
      const modelValue = modelSelect && modelSelect.value === 'custom'
        ? (customModelInput ? customModelInput.value.trim() : '')
        : (modelSelect ? modelSelect.value : 'google/gemini-2.5-flash');
      localStorage.setItem('tinder_ext_openRouterApiKey', JSON.stringify(apiKeyInput.value.trim()));
      localStorage.setItem('tinder_ext_aiSystemPrompt', JSON.stringify(systemPromptInput.value.trim()));
      localStorage.setItem('tinder_ext_aiUserPrompt', JSON.stringify(userPromptInput.value.trim()));
      localStorage.setItem('tinder_ext_aiModel', JSON.stringify(modelValue));
    } catch (e2) {}
    console.error(i18n.t('ai.aiError') + ' saveAIConfig:', e);
  }
}

function getSelectedModel() {
  const model = modelSelect && modelSelect.value === 'custom'
    ? (customModelInput ? customModelInput.value.trim() : 'google/gemini-2.5-flash')
    : (modelSelect ? modelSelect.value : 'google/gemini-2.5-flash');
  return model || 'google/gemini-2.5-flash';
}

if (customModelInput) {
  customModelInput.addEventListener('input', saveAIConfig);
}

if (systemPromptInput) {
  systemPromptInput.addEventListener('input', debouncedSavePrompts);
}

if (userPromptInput) {
  userPromptInput.addEventListener('input', debouncedSavePrompts);
}

// Debounced auto-save for prompt textareas
let promptsDebounceTimer = null;
function debouncedSavePrompts() {
  clearTimeout(promptsDebounceTimer);
  promptsDebounceTimer = setTimeout(() => {
    saveAIConfig();
  }, 1500);
}

let messageDraftDebounceTimer = null;

async function saveMessageDraft(draftText) {
  const value = typeof draftText === 'string' ? draftText : '';
  try {
    await chrome.storage.local.set({ [MESSAGE_DRAFT_KEY]: value });
  } catch (e) {
    try {
      localStorage.setItem(MESSAGE_DRAFT_FALLBACK_KEY, JSON.stringify(value));
    } catch (e2) {}
  }
}

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab || null;
}

async function loadMessageDraft() {
  try {
    const result = await chrome.storage.local.get([MESSAGE_DRAFT_KEY]);
    const saved = result[MESSAGE_DRAFT_KEY];
    return typeof saved === 'string' ? saved : '';
  } catch (e) {
    try {
      const raw = localStorage.getItem(MESSAGE_DRAFT_FALLBACK_KEY);
      const parsed = raw ? JSON.parse(raw) : '';
      return typeof parsed === 'string' ? parsed : '';
    } catch (e2) {
      return '';
    }
  }
}

function debouncedSaveMessageDraft() {
  clearTimeout(messageDraftDebounceTimer);
  messageDraftDebounceTimer = setTimeout(() => {
    if (messageTextInput) {
      void saveMessageDraft(messageTextInput.value);
    }
  }, 300);
}

if (messageTextInput) {
  messageTextInput.addEventListener('input', debouncedSaveMessageDraft);
}

async function restoreMessageDraft() {
  if (!messageTextInput) return;
  const saved = await loadMessageDraft();
  if (saved) {
    messageTextInput.value = saved;
  }
}


// Get current time slot
function getCurrentTimeSlot() {
  const hour = new Date().getHours();
  if (hour >= 5 && hour < 11) {
    return { slot: 'morning', label: i18n.t('timeSlot.morning'), emoji: '☀️' };
  } else if (hour >= 11 && hour < 17) {
    return { slot: 'noon', label: i18n.t('timeSlot.noon'), emoji: '🌞' };
  } else {
    return { slot: 'evening', label: i18n.t('timeSlot.evening'), emoji: '🌙' };
  }
}

// Get quotes based on current time
function getTimeBasedQuotes() {
  const timeSlot = getCurrentTimeSlot();
  let quotesText = '';

  switch (timeSlot.slot) {
    case 'morning':
      quotesText = morningQuotesInput.value;
      break;
    case 'noon':
      quotesText = noonQuotesInput.value;
      break;
    case 'evening':
      quotesText = eveningQuotesInput.value;
      break;
  }

  return quotesText.trim().split('\n').map(q => q.trim()).filter(q => q.length > 0);
}

// Update time slot display
function updateTimeSlotDisplay() {
  if (currentTimeSlotEl) {
    const timeSlot = getCurrentTimeSlot();
    currentTimeSlotEl.textContent = timeSlot.label;
  }
}

// Toggle time-based quotes mode
if (timeBasedQuotesCheckbox) {
  timeBasedQuotesCheckbox.addEventListener('change', () => {
    if (timeBasedQuotesCheckbox.checked) {
      singleQuotesGroup.style.display = 'none';
      timeBasedQuotesGroup.style.display = 'block';
      updateTimeSlotDisplay();
    } else {
      singleQuotesGroup.style.display = 'block';
      timeBasedQuotesGroup.style.display = 'none';
    }
  });
}

// Update time slot on load
setTimeout(updateTimeSlotDisplay, 100);

// Message source mode: keeps the visible Message tab and the saved AI mode in sync.
function syncMessageModeUI(mode) {
  const normalizedMode = ['fixed', 'random', 'ai'].includes(mode) ? mode : 'fixed';
  const isRandom = normalizedMode === 'random';
  const isAi = normalizedMode === 'ai';

  if (randomQuoteCheckbox) {
    randomQuoteCheckbox.checked = isRandom;
  }

  if (singleMessageGroup) {
    singleMessageGroup.style.display = normalizedMode === 'fixed' ? 'block' : 'none';
  }

  if (quotesGroup) {
    quotesGroup.style.display = isRandom ? 'block' : 'none';
  }

  if (aiBulkNoteEl) {
    aiBulkNoteEl.style.display = isAi ? 'block' : 'none';
  }

  if (activeMessageSourceEl) {
    const sourceKey = normalizedMode === 'ai'
      ? 'msg.sourceAi'
      : normalizedMode === 'random'
        ? 'msg.sourceRandom'
        : 'msg.sourceFixed';
    activeMessageSourceEl.setAttribute('data-i18n', sourceKey);
    activeMessageSourceEl.textContent = i18n.t(sourceKey);
  }

  sendModeOptions.forEach(option => {
    option.classList.toggle('active', option.dataset.sendMode === normalizedMode);
  });
}

sendModeOptions.forEach(option => {
  option.addEventListener('click', () => {
    setAIMode(option.dataset.sendMode);
  });
});

// Legacy hidden checkbox path, kept for compatibility with restored state/tests.
if (randomQuoteCheckbox) {
  randomQuoteCheckbox.addEventListener('change', () => {
    setAIMode(randomQuoteCheckbox.checked ? 'random' : 'fixed');
  });
}

// ========== SAVED MESSAGES ==========
const savedMessagesListEl = document.getElementById('savedMessagesList');
const savedMsgNameInput = document.getElementById('savedMsgNameInput');
const saveMsgPresetBtn = document.getElementById('saveMsgPresetBtn');
const savedMessagesSection = document.getElementById('savedMessagesSection');
const quickSaveMsgBtn = document.getElementById('quickSaveMsgBtn');
const quickSaveMsgStatus = document.getElementById('quickSaveMsgStatus');

const MAX_SAVED = 20;
let quickSaveStatusTimer = null;

async function loadSavedMessages() {
  try {
    const result = await chrome.storage.local.get(['savedMessages']);
    return result.savedMessages || [];
  } catch (e) {
    try {
      const raw = localStorage.getItem('tinder_ext_savedMessages');
      return raw ? JSON.parse(raw) : [];
    } catch (e2) { return []; }
  }
}

async function persistSavedMessages(messages) {
  try {
    await chrome.storage.local.set({ savedMessages: messages });
  } catch (e) {
    try { localStorage.setItem('tinder_ext_savedMessages', JSON.stringify(messages)); } catch (e2) {}
  }
}

async function renderSavedMessages() {
  const messages = await loadSavedMessages();
  if (messages.length === 0) {
    savedMessagesListEl.innerHTML = '<div class="saved-empty">' + i18n.t('msg.savedEmpty') + '</div>';
    return;
  }

  savedMessagesListEl.innerHTML = messages.map((msg, idx) => `
    <div class="saved-item" data-idx="${idx}">
      <div class="saved-item-body">
        <div class="saved-item-name">${escapeHtml(msg.name || i18n.t('msg.noTitle'))}</div>
        <div class="saved-item-preview">${escapeHtml(msg.message || '')}</div>
      </div>
      <button class="saved-item-delete" data-idx="${idx}" title="${i18n.t('msg.delete')}">
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
      </button>
    </div>
  `).join('');

  // Click to load
  savedMessagesListEl.querySelectorAll('.saved-item').forEach(item => {
    item.addEventListener('click', (e) => {
      if (e.target.closest('.saved-item-delete')) return;
      const idx = parseInt(item.dataset.idx);
      loadSavedPreset(idx);
    });
  });

  // Delete buttons
  savedMessagesListEl.querySelectorAll('.saved-item-delete').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const idx = parseInt(btn.dataset.idx);
      deleteSavedPreset(idx);
    });
  });
}

function buildPresetName(message) {
  const firstLine = message
    .split('\n')
    .map(line => line.trim())
    .find(Boolean) || '';
  const compact = firstLine.replace(/\s+/g, ' ');
  if (compact.length <= 32) return compact;
  return compact.slice(0, 32).trim() + '...';
}

function showQuickSaveStatus(message, type = 'success') {
  if (!quickSaveMsgStatus) return;
  clearTimeout(quickSaveStatusTimer);
  quickSaveMsgStatus.textContent = message;
  quickSaveMsgStatus.classList.toggle('error', type === 'error');
  quickSaveMsgStatus.style.display = 'block';
  quickSaveStatusTimer = setTimeout(() => {
    quickSaveMsgStatus.style.display = 'none';
    quickSaveMsgStatus.classList.remove('error');
  }, 1800);
}

async function saveCurrentMessagePreset(options = {}) {
  const { fallbackToMessageTitle = false } = options;
  const message = messageTextInput.value.trim();

  if (!message) {
    messageTextInput.style.borderColor = 'var(--red)';
    setTimeout(() => { messageTextInput.style.borderColor = ''; }, 1500);
    throw new Error(i18n.t('msg.enterMessage'));
  }

  const enteredName = savedMsgNameInput ? savedMsgNameInput.value.trim() : '';
  const name = enteredName || (fallbackToMessageTitle ? buildPresetName(message) : '');

  const messages = await loadSavedMessages();
  if (messages.length >= MAX_SAVED) {
    messages.shift();
  }
  messages.push({ name, message });
  await persistSavedMessages(messages);

  if (savedMsgNameInput) {
    savedMsgNameInput.value = '';
  }
  await renderSavedMessages();
  return { name, message };
}

async function loadSavedPreset(idx) {
  const messages = await loadSavedMessages();
  const preset = messages[idx];
  if (!preset) return;

  messageTextInput.value = preset.message || '';
  setAIMode('fixed');

  if (savedMessagesSection) savedMessagesSection.open = false;
  savedMsgNameInput.value = preset.name || '';
  messageTextInput.focus();
}

async function deleteSavedPreset(idx) {
  const messages = await loadSavedMessages();
  messages.splice(idx, 1);
  await persistSavedMessages(messages);
  await renderSavedMessages();
}

if (saveMsgPresetBtn) {
  saveMsgPresetBtn.addEventListener('click', async () => {
    try {
      await saveCurrentMessagePreset();
    } catch (e) {
      showQuickSaveStatus(e.message, 'error');
    }
  });
}

if (quickSaveMsgBtn) {
  quickSaveMsgBtn.addEventListener('click', async () => {
    try {
      await saveCurrentMessagePreset({ fallbackToMessageTitle: true });
      showQuickSaveStatus(i18n.t('msg.savedOk'));
    } catch (e) {
      showQuickSaveStatus(e.message, 'error');
    }
  });
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}


const fetchQuotesBtn = document.getElementById('fetchQuotesBtn');
const quotesStatusEl = document.getElementById('quotesStatus');

fetchQuotesBtn.addEventListener('click', async () => {
  fetchQuotesBtn.disabled = true;
  fetchQuotesBtn.textContent = '⏳ ' + i18n.t('msg.fetching');
  quotesStatusEl.textContent = '';

  try {
    // ZenQuotes API
    const response = await fetch('https://zenquotes.io/api/quotes');

    if (!response.ok) {
      throw new Error(i18n.t('msg.apiNoResponse'));
    }

    const data = await response.json();

    // Format quotes - ZenQuotes format: { q: "quote", a: "author" }
    const quotes = data.slice(0, 40).map(q => `${q.q} - ${q.a}`);

    // Thêm vào textarea
    const currentQuotes = quotesListInput.value.trim();
    const newQuotes = quotes.join('\n');
    quotesListInput.value = currentQuotes ? `${currentQuotes}\n${newQuotes}` : newQuotes;

    quotesStatusEl.textContent = '✅ ' + i18n.t('msg.quotesAdded').replace('{n}', quotes.length);
    quotesStatusEl.style.color = '#4CAF50';

  } catch (error) {
    console.error(i18n.t('ai.aiError') + ' fetch quotes:', error);

    // Fallback: thêm quotes tiếng Việt mặc định
    const fallbackQuotes = [
      'Hạnh phúc không đến từ việc có nhiều, mà từ việc biết đủ. 🌸',
      'Mỗi ngày là một cơ hội mới để bắt đầu lại. 🌅',
      'Cuộc sống ngắn ngủi, hãy yêu thương nhiều hơn. ❤️',
      'Nụ cười là ngôn ngữ chung của nhân loại. 😊',
      'Thành công bắt đầu từ việc dám ước mơ. ⭐',
      'Hãy là phiên bản tốt nhất của chính mình. 💪',
      'Mọi thứ đều có thể nếu bạn tin tưởng. 🌈',
      'Yêu thương bản thân là bước đầu tiên. 💕'
    ];

    const currentQuotes = quotesListInput.value.trim();
    const newQuotes = fallbackQuotes.join('\n');
    quotesListInput.value = currentQuotes ? `${currentQuotes}\n${newQuotes}` : newQuotes;

    quotesStatusEl.textContent = '✅ ' + i18n.t('msg.quotesFallback').replace('{n}', fallbackQuotes.length);
    quotesStatusEl.style.color = '#FF9800';
  }

  fetchQuotesBtn.disabled = false;
});

// Common elements
const statusEl = document.getElementById('status');
const progressEl = document.getElementById('progress');

// Helper: Inject content script và gửi message
async function sendMessageToTab(message) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  if (!tab.url.includes('tinder.com')) {
    throw new Error('NOT_TINDER');
  }

  // Inject content script trước
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['tinder-auto-click.js']
    });
  } catch (e) {
    console.log('Script đã được inject hoặc lỗi:', e);
  }

  // Đợi một chút để script load
  await new Promise(resolve => setTimeout(resolve, 300));

  // Gửi message (Promise-based overload for async responses)
  try {
    const response = await chrome.tabs.sendMessage(tab.id, message);
    return response;
  } catch (e) {
    throw new Error(e.message || chrome.runtime.lastError?.message || 'Message failed');
  }
}

// Update UI
function updateGamepadUI(running) {
  startBtn.style.display = running ? 'none' : 'block';
  stopBtn.style.display = running ? 'block' : 'none';
}

function updateMessageUI(running) {
  startMsgBtn.style.display = running ? 'none' : 'block';
  stopMsgBtn.style.display = running ? 'block' : 'none';
}

// === GAMEPAD AUTO CLICK ===
startBtn.addEventListener('click', async () => {
  try {
    const clickCount = parseInt(clickCountInput.value) || 10;
    const minDelay = (parseFloat(minDelayInput.value) || 1) * 1000;
    const maxDelay = (parseFloat(maxDelayInput.value) || 3) * 1000;

    statusEl.textContent = i18n.t('msg.connecting');
    statusEl.style.display = 'block';
    statusEl.style.color = 'var(--text-secondary)';

    const response = await sendMessageToTab({
      action: 'startAutoClick',
      count: clickCount,
      minDelay: minDelay,
      maxDelay: maxDelay
    });

    if (response?.started) {
      updateGamepadUI(true);
      statusEl.textContent = i18n.t('swipe.running');
      statusEl.style.color = 'var(--green)';
      progressEl.style.display = 'block';
      progressEl.textContent = '0 / ' + clickCount;
    }
  } catch (e) {
    if (e.message === 'NOT_TINDER') {
      statusEl.textContent = i18n.t('error.notTinder');
    } else {
      statusEl.textContent = i18n.t('error').replace('{msg}', e.message);
    }
    statusEl.style.color = 'var(--red)';
  }
});

stopBtn.addEventListener('click', async () => {
  try {
    const response = await sendMessageToTab({ action: 'stopAutoClick' });
    if (response?.stopped) {
      updateGamepadUI(false);
      statusEl.textContent = i18n.t('msg.stopped');
      statusEl.style.color = 'var(--text-muted)';
      progressEl.style.display = 'none';
    }
  } catch (e) {
    statusEl.textContent = i18n.t('error').replace('{msg}', e.message);
    statusEl.style.color = 'var(--red)';
  }
});

// === BULK MESSAGE ===
startMsgBtn.addEventListener('click', async () => {
  try {
    let message = '';
    let quotes = [];
    let useRandomQuotes = false;

    const sendMode = ['fixed', 'random', 'ai'].includes(selectedAIMode) ? selectedAIMode : 'fixed';

    if (sendMode === 'ai') {
      const result = await chrome.storage.local.get([
        'openRouterApiKey',
        'aiSystemPrompt',
        'aiUserPrompt',
        'aiModel'
      ]);

      if (!result.openRouterApiKey) {
        statusEl.textContent = i18n.t('msg.noAiKey');
        statusEl.style.display = 'block';
        statusEl.style.color = 'var(--red)';
        return;
      }

      const count = parseInt(messageCountInput.value) || 0;
      const minDelay = (parseFloat(msgMinDelayInput.value) || 3) * 1000;
      const maxDelay = (parseFloat(msgMaxDelayInput.value) || 5) * 1000;

      statusEl.textContent = i18n.t('msg.connectingAi');
      statusEl.style.display = 'block';
      statusEl.style.color = 'var(--accent)';

      const response = await sendMessageToTab({
        action: 'startBulkMessage',
        message: '',
        quotes: [],
        useRandomQuotes: false,
        count: count,
        minDelay: minDelay,
        maxDelay: maxDelay,
        aiMode: true,
        openRouterApiKey: result.openRouterApiKey,
        aiSystemPrompt: result.aiSystemPrompt,
        aiUserPrompt: result.aiUserPrompt,
        aiModel: result.aiModel || 'google/gemini-2.5-flash'
      });

      if (response?.started) {
        updateMessageUI(true);
        statusEl.textContent = i18n.t('msg.sendingAi');
        statusEl.style.color = 'var(--green)';
        progressEl.style.display = 'block';
        progressEl.textContent = '0 / ' + (count || '?');
      } else {
        statusEl.textContent = i18n.t('msg.cantStart');
        statusEl.style.color = 'var(--red)';
      }
      return;
    }

    useRandomQuotes = sendMode === 'random';

    if (useRandomQuotes) {
      const useTimeBased = timeBasedQuotesCheckbox && timeBasedQuotesCheckbox.checked;

      if (useTimeBased) {
        quotes = getTimeBasedQuotes();
        const timeSlot = getCurrentTimeSlot();
        console.log(`Using quotes for ${timeSlot.label}:`, quotes);
      } else {
        const quotesText = quotesListInput.value.trim();
        quotes = quotesText.split('\n').map(q => q.trim()).filter(q => q.length > 0);
      }

      if (quotes.length === 0) {
        statusEl.textContent = i18n.t('msg.notEnoughQuotes');
        statusEl.style.display = 'block';
        statusEl.style.color = 'var(--red)';
        return;
      }
    } else {
      message = messageTextInput.value.trim();
      if (!message) {
        statusEl.textContent = i18n.t('msg.enterMessage');
        statusEl.style.display = 'block';
        statusEl.style.color = 'var(--red)';
        return;
      }
    }

    const count = parseInt(messageCountInput.value) || 0;
    const minDelay = (parseFloat(msgMinDelayInput.value) || 3) * 1000;
    const maxDelay = (parseFloat(msgMaxDelayInput.value) || 5) * 1000;

    statusEl.textContent = i18n.t('msg.connecting');
    statusEl.style.display = 'block';
    statusEl.style.color = 'var(--accent)';

    const response = await sendMessageToTab({
      action: 'startBulkMessage',
      message: message,
      quotes: quotes,
      useRandomQuotes: useRandomQuotes,
      count: count,
      minDelay: minDelay,
      maxDelay: maxDelay
    });

    if (response?.started) {
      updateMessageUI(true);
      statusEl.textContent = i18n.t('msg.sending');
      statusEl.style.color = 'var(--green)';
      progressEl.style.display = 'block';
      progressEl.textContent = '0 / ' + (count || '?');
    } else {
      statusEl.textContent = i18n.t('msg.cantStart');
      statusEl.style.color = 'var(--red)';
    }
  } catch (e) {
    if (e.message === 'NOT_TINDER') {
      statusEl.textContent = i18n.t('error.notTinder');
    } else {
      statusEl.textContent = i18n.t('error').replace('{msg}', e.message);
    }
    statusEl.style.color = 'var(--red)';
  }
});

stopMsgBtn.addEventListener('click', async () => {
  try {
    const response = await sendMessageToTab({ action: 'stopBulkMessage' });
    if (response?.stopped) {
      updateMessageUI(false);
      statusEl.textContent = i18n.t('msg.stopped');
      statusEl.style.color = 'var(--text-muted)';
      progressEl.style.display = 'none';
    }
  } catch (e) {
    statusEl.textContent = i18n.t('error').replace('{msg}', e.message);
    statusEl.style.color = 'var(--red)';
  }
});

// ========== SINGLE AI MESSAGE GENERATION (Message Tab) ==========
const generateAiMsgBtn = document.getElementById('generateAiMsgBtn');
const generateAiStatus = document.getElementById('generateAiStatus');
const generateAiPreview = document.getElementById('generateAiPreview');
const generateAiPreviewText = document.getElementById('generateAiPreviewText');
const useAiMsgBtn = document.getElementById('useAiMsgBtn');
const regenerateAiMsgBtn = document.getElementById('regenerateAiMsgBtn');
let lastGeneratedMessage = '';

async function generateSingleAIMessage() {
  statusEl.textContent = i18n.t('msg.generating');
  statusEl.style.display = 'block';
  statusEl.style.color = 'var(--accent)';

  const aiConfig = await chrome.storage.local.get([
    'openRouterApiKey',
    'aiSystemPrompt',
    'aiUserPrompt',
    'aiModel'
  ]);

  if (!aiConfig.openRouterApiKey) {
    showGenStatus(i18n.t('msg.aiNoApiKey'), 'error');
    statusEl.textContent = i18n.t('msg.aiNoApiKey');
    statusEl.style.color = 'var(--red)';
    return null;
  }

  generateAiMsgBtn.disabled = true;
  generateAiMsgBtn.innerHTML = '<svg class="spinner" style="width:14px;height:14px;border:2px solid rgba(232,96,76,0.2);border-top-color:var(--accent);border-radius:50%;animation:spin .7s linear infinite;display:inline-block;flex-shrink:0;" viewBox="0 0 24 24"></svg> <span>' + i18n.t('msg.generating') + '</span>';

  try {
    const response = await sendMessageToTab({
      action: 'generateProfileAIMessage',
      apiKey: aiConfig.openRouterApiKey,
      systemPrompt: aiConfig.aiSystemPrompt,
      userPrompt: aiConfig.aiUserPrompt,
      model: aiConfig.aiModel || 'google/gemini-2.5-flash'
    });

    generateAiMsgBtn.disabled = false;
    generateAiMsgBtn.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2a10 10 0 100 20A10 10 0 0012 2zm0 18a8 8 0 110-16 8 8 0 010 16zm-1-5h2v2h-2zm1.61-9.96a2.5 2.5 0 01.89 2.46h-1.78a1.5 1.5 0 00-1.78 1.33V15h2v1h-3.5a.5.5 0 010-1H11v-1.54a2.5 2.5 0 012.61-2.5z"/></svg> <span>' + i18n.t('msg.aiGenerate') + '</span>';

    if (response?.success && response.message) {
      lastGeneratedMessage = response.message;
      generateAiPreviewText.textContent = response.message;
      generateAiPreview.classList.add('show');
      document.getElementById('aiPreviewActions').style.display = 'flex';
      showGenStatus(i18n.t('msg.aiCreated'), 'success');
      statusEl.textContent = i18n.t('msg.aiCreated');
      statusEl.style.color = 'var(--green)';
      return response.message;
    } else {
      const errMsg = response?.error || i18n.t('msg.noResponse');
      showGenStatus(errMsg, 'error');
      statusEl.textContent = errMsg;
      statusEl.style.color = 'var(--red)';
      return null;
    }
  } catch (e) {
    generateAiMsgBtn.disabled = false;
    generateAiMsgBtn.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2a10 10 0 100 20A10 10 0 0012 2zm0 18a8 8 0 110-16 8 8 0 010 16zm-1-5h2v2h-2zm1.61-9.96a2.5 2.5 0 01.89 2.46h-1.78a1.5 1.5 0 00-1.78 1.33V15h2v1h-3.5a.5.5 0 010-1H11v-1.54a2.5 2.5 0 012.61-2.5z"/></svg> <span>' + i18n.t('msg.aiGenerate') + '</span>';
    showGenStatus(i18n.t('ai.aiError') + ' ' + e.message, 'error');
    statusEl.textContent = i18n.t('ai.aiError') + ' ' + e.message;
    statusEl.style.color = 'var(--red)';
    return null;
  }
}

function showGenStatus(msg, type) {
  generateAiStatus.textContent = msg;
  generateAiStatus.style.display = 'block';
  generateAiStatus.className = 'alert ' + (type === 'success' ? 'alert-success' : 'alert-error');
  generateAiStatus.classList.add('show');
}

if (generateAiMsgBtn) {
  generateAiMsgBtn.addEventListener('click', () => {
    generateSingleAIMessage();
  });
}

if (useAiMsgBtn) {
  useAiMsgBtn.addEventListener('click', () => {
    if (lastGeneratedMessage) {
      const messageTextInput = document.getElementById('messageText');
      if (messageTextInput) {
        messageTextInput.value = lastGeneratedMessage;
        messageTextInput.focus();
        void saveMessageDraft(lastGeneratedMessage);
        setAIMode('fixed');
      }
      generateAiPreview.style.display = 'none';
      generateAiStatus.style.display = 'none';
      lastGeneratedMessage = '';
    }
  });
}

if (regenerateAiMsgBtn) {
  regenerateAiMsgBtn.addEventListener('click', () => {
    generateSingleAIMessage();
  });
}

// Listen for progress updates
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'updateProgress') {
    progressEl.textContent = `${request.current} / ${request.total}`;
    progressEl.style.display = 'block';
  }

  if (request.action === 'completed') {
    updateGamepadUI(false);
    updateMessageUI(false);
    statusEl.textContent = i18n.t('swipe.complete');
    statusEl.style.display = 'none';
    progressEl.textContent = i18n.t('msg.processed').replace('{n}', request.total);
  }

  if (request.action === 'error') {
    updateGamepadUI(false);
    updateMessageUI(false);
    statusEl.textContent = request.message;
    statusEl.style.display = 'block';
    statusEl.style.color = 'var(--red)';
    progressEl.style.display = 'none';
  }
});

// ========== HISTORY ==========
const historyListEl = document.getElementById('historyList');
const historyCountEl = document.getElementById('historyCount');
const refreshHistoryBtn = document.getElementById('refreshHistoryBtn');
const clearHistoryBtn = document.getElementById('clearHistoryBtn');

// Render history từ chrome.storage.local (popup có thể truy cập trực tiếp)
async function loadHistory() {
  try {
    const result = await chrome.storage.local.get(['messageHistory']);
    const history = result.messageHistory || [];

    historyCountEl.textContent = i18n.t('history.total').replace('{n}', history.length);

    if (history.length === 0) {
      historyListEl.innerHTML = '<div style="text-align: center; color: #999; padding: 20px;">' + i18n.t('history.empty') + '</div>';
      return;
    }

    historyListEl.innerHTML = history.slice(0, 100).map(item => `
      <div class="history-item">
        <div class="history-name">${item.name || i18n.t('history.unknown')}</div>
        <div class="history-msg">${item.message || ''}</div>
        <div class="history-time">${item.date || ''}</div>
      </div>
    `).join('');
  } catch (e) {
    try {
      const raw = localStorage.getItem('tinder_ext_messageHistory');
      const history = raw ? JSON.parse(raw) : [];
      historyCountEl.textContent = i18n.t('history.total').replace('{n}', history.length);
      if (history.length === 0) {
        historyListEl.innerHTML = '<div style="text-align: center; color: #999; padding: 20px;">' + i18n.t('history.empty') + '</div>';
        return;
      }
      historyListEl.innerHTML = history.slice(0, 100).map(item => `
        <div class="history-item">
          <div class="history-name">${item.name || i18n.t('history.unknown')}</div>
          <div class="history-msg">${item.message || ''}</div>
          <div class="history-time">${item.date || ''}</div>
        </div>
      `).join('');
    } catch (e2) {
      historyListEl.innerHTML = '<div style="color: red; text-align:center; padding:20px;">' + i18n.t('history.error') + '</div>';
    }
    console.error(i18n.t('ai.aiError') + ' load history:', e);
  }
}

// Clear history
async function clearHistory() {
  if (!confirm(i18n.t('history.clearConfirm'))) return;
  try {
    await chrome.storage.local.set({ messageHistory: [] });
  } catch (e) {
    try { localStorage.setItem('tinder_ext_messageHistory', JSON.stringify([])); } catch (e2) {}
    console.error(i18n.t('ai.aiError') + ' delete history:', e);
  }
  loadHistory();
}

// Event listeners
if (refreshHistoryBtn) {
  refreshHistoryBtn.addEventListener('click', loadHistory);
}

if (clearHistoryBtn) {
  clearHistoryBtn.addEventListener('click', clearHistory);
}

// Auto load history khi chuyển sang tab history
document.querySelectorAll('.tab').forEach(tab => {
  tab.addEventListener('click', () => {
    if (tab.dataset.tab === 'history') {
      loadHistory();
    }
  });
});

// ========== AI PANEL ==========
const saveApiKeyBtn = document.getElementById('saveApiKeyBtn');
const testApiKeyBtn = document.getElementById('testApiKeyBtn');
const testResultEl = document.getElementById('testResult');
const apiKeyStatusEl = document.getElementById('apiKeyStatus');
const modeOptions = document.querySelectorAll('.mode-card');

// Load saved AI config on startup
async function loadAIConfig() {
  try {
    const result = await chrome.storage.local.get([
      'openRouterApiKey',
      'aiSystemPrompt',
      'aiUserPrompt',
      'aiMode',
      'aiModel'
    ]);

    if (result.openRouterApiKey) {
      apiKeyInput.value = result.openRouterApiKey;
      updateApiKeyStatus(true);
    }

    if (result.aiSystemPrompt) {
      systemPromptInput.value = result.aiSystemPrompt;
    }

    if (result.aiUserPrompt) {
      userPromptInput.value = result.aiUserPrompt;
    }

    const mode = result.aiMode || 'fixed';
    selectedAIMode = mode;
    setAIMode(mode);

    // Load saved model
    if (result.aiModel) {
      if (modelSelect) {
        // Check if saved model exists in options
        const exists = [...modelSelect.options].some(opt => opt.value === result.aiModel);
        if (exists) {
          modelSelect.value = result.aiModel;
        } else {
          modelSelect.value = 'custom';
          if (customModelInput) {
            customModelInput.value = result.aiModel;
            customModelInput.style.display = 'block';
          }
        }
      }
    }
  } catch (e) {
    try {
      const apiKey = localStorage.getItem('tinder_ext_openRouterApiKey');
      const systemPrompt = localStorage.getItem('tinder_ext_aiSystemPrompt');
      const userPrompt = localStorage.getItem('tinder_ext_aiUserPrompt');
      const aiModel = localStorage.getItem('tinder_ext_aiModel');
      if (apiKey) apiKeyInput.value = JSON.parse(apiKey);
      if (systemPrompt) systemPromptInput.value = JSON.parse(systemPrompt);
      if (userPrompt) userPromptInput.value = JSON.parse(userPrompt);
      if (aiModel && modelSelect) {
        const parsed = JSON.parse(aiModel);
        const exists = [...modelSelect.options].some(opt => opt.value === parsed);
        if (exists) modelSelect.value = parsed;
        else {
          modelSelect.value = 'custom';
          if (customModelInput) { customModelInput.value = parsed; customModelInput.style.display = 'block'; }
        }
      }
    } catch (e2) {}
    console.error(i18n.t('ai.aiError') + ' load AI config:', e);
  }
}

function updateApiKeyStatus(configured) {
  const lang = i18n.lang;
  if (configured) {
    apiKeyStatusEl.className = 'api-badge configured';
    apiKeyStatusEl.innerHTML = '<div class="dot"></div><span>' + i18n.t('ai.apiConfigured') + '</span>';
  } else {
    apiKeyStatusEl.className = 'api-badge not-configured';
    apiKeyStatusEl.innerHTML = '<div class="dot"></div><span>' + i18n.t('ai.apiNotConfigured') + '</span>';
  }
}

function showTestResult(msg, type) {
  testResultEl.textContent = msg;
  testResultEl.className = 'alert ' + (type === 'success' ? 'alert-success' : type === 'info' ? 'alert-info' : 'alert-error');
  testResultEl.classList.add('show');
}

function clearTestResult() {
  testResultEl.className = 'alert';
  testResultEl.classList.remove('show');
}

function setAIMode(mode) {
  selectedAIMode = ['fixed', 'random', 'ai'].includes(mode) ? mode : 'fixed';
  modeOptions.forEach(opt => {
    opt.classList.remove('selected');
    const radio = opt.querySelector('input[type="radio"]');
    radio.checked = opt.dataset.mode === selectedAIMode;
    if (opt.dataset.mode === selectedAIMode) {
      opt.classList.add('selected');
    }
  });
  syncMessageModeUI(selectedAIMode);
  chrome.storage.local.set({ aiMode: selectedAIMode }).catch(() => {
    try { localStorage.setItem('tinder_ext_aiMode', JSON.stringify(selectedAIMode)); } catch(e2) {}
  });
}

modeOptions.forEach(opt => {
  opt.addEventListener('click', () => {
    const mode = opt.dataset.mode;
    const radio = opt.querySelector('input[type="radio"]');
    radio.checked = true;
    setAIMode(mode);
  });
});

saveApiKeyBtn.addEventListener('click', async () => {
  const apiKey = apiKeyInput.value.trim();
  if (!apiKey) {
    showTestResult(i18n.t('ai.enterApiKey'), 'error');
    return;
  }

  saveApiKeyBtn.disabled = true;
  saveApiKeyBtn.innerHTML = '<span>' + i18n.t('ai.saving') + '</span>';

  try {
    const modelValue = modelSelect && modelSelect.value === 'custom'
      ? (customModelInput ? customModelInput.value.trim() : '')
      : (modelSelect ? modelSelect.value : 'google/gemini-2.5-flash');

    await chrome.storage.local.set({
      openRouterApiKey: apiKey,
      aiSystemPrompt: systemPromptInput.value.trim(),
      aiUserPrompt: userPromptInput.value.trim(),
      aiModel: modelValue
    });

    showTestResult(i18n.t('ai.apiKeySaved'), 'success');
    updateApiKeyStatus(true);
    setTimeout(clearTestResult, 2000);
  } catch (e) {
    // Fallback to localStorage
    try {
      const modelValue = modelSelect && modelSelect.value === 'custom'
        ? (customModelInput ? customModelInput.value.trim() : '')
        : (modelSelect ? modelSelect.value : 'google/gemini-2.5-flash');
      localStorage.setItem('tinder_ext_openRouterApiKey', JSON.stringify(apiKey));
      localStorage.setItem('tinder_ext_aiSystemPrompt', JSON.stringify(systemPromptInput.value.trim()));
      localStorage.setItem('tinder_ext_aiUserPrompt', JSON.stringify(userPromptInput.value.trim()));
      localStorage.setItem('tinder_ext_aiModel', JSON.stringify(modelValue));
      showTestResult(i18n.t('ai.apiKeySaved') + ' (localStorage)', 'success');
      updateApiKeyStatus(true);
      setTimeout(clearTestResult, 2000);
    } catch (e2) {
      showTestResult(i18n.t('ai.saveError').replace('{msg}', e.message), 'error');
    }
  }

  saveApiKeyBtn.disabled = false;
  saveApiKeyBtn.innerHTML = '<span>' + i18n.t('ai.save') + '</span>';
});

testApiKeyBtn.addEventListener('click', async () => {
  const apiKey = apiKeyInput.value.trim();
  if (!apiKey) {
    showTestResult(i18n.t('ai.enterApiKey'), 'error');
    return;
  }

  testApiKeyBtn.disabled = true;
  testApiKeyBtn.textContent = i18n.t('ai.checking');
  showTestResult(i18n.t('ai.checking'), 'info');

  try {
    const openrouter = OpenRouter;
    const result = await openrouter.validateKey(apiKey);
    if (result.valid) {
      showTestResult(i18n.t('ai.apiKeyValid'), 'success');
      updateApiKeyStatus(true);
    } else {
      showTestResult(result.error || i18n.t('ai.apiKeyInvalid'), 'error');
      updateApiKeyStatus(false);
    }
  } catch (e) {
    showTestResult(i18n.t('ai.aiError') + ' ' + e.message, 'error');
  }

  testApiKeyBtn.disabled = false;
  testApiKeyBtn.textContent = i18n.t('ai.test');
  setTimeout(clearTestResult, 5000);
});

const savePromptBtn = document.getElementById('savePromptBtn');
const promptSaveStatus = document.getElementById('promptSaveStatus');

if (savePromptBtn) {
  savePromptBtn.addEventListener('click', async () => {
    savePromptBtn.disabled = true;
    promptSaveStatus.style.display = 'block';
    promptSaveStatus.textContent = i18n.t('ai.saving');
    promptSaveStatus.style.color = 'var(--text-muted)';

    try {
      await saveAIConfig();
      promptSaveStatus.textContent = i18n.t('ai.promptsSaved');
      promptSaveStatus.style.color = 'var(--green)';
      setTimeout(() => { promptSaveStatus.style.display = 'none'; }, 2000);
    } catch (e) {
      promptSaveStatus.textContent = i18n.t('ai.saveError').replace('{msg}', e.message);
      promptSaveStatus.style.color = 'var(--red)';
      setTimeout(() => { promptSaveStatus.style.display = 'none'; }, 3000);
    }

    savePromptBtn.disabled = false;
  });
}

testAiGenerateBtn.addEventListener('click', async () => {
  const apiKey = apiKeyInput.value.trim();
  if (!apiKey) {
    showTestResult(i18n.t('ai.saveFirst'), 'error');
    return;
  }

  aiGeneratingEl.style.display = 'flex';
  aiPreviewEl.classList.remove('show');
  testAiGenerateBtn.disabled = true;

  try {
    const model = getSelectedModel();
    const openrouter = OpenRouter;
    const result = await openrouter.generateMessage(apiKey, {
      model: model,
      systemPrompt: systemPromptInput.value.trim(),
      userPrompt: userPromptInput.value.trim(),
      profile: i18n.lang === 'vi'
        ? 'mot co gai 25 tuoi, thich du lich va chup anh, song o TP.HCM'
        : 'a 25 year old girl who loves traveling and photography, lives in Ho Chi Minh City'
    });

    aiGeneratingEl.style.display = 'none';
    testAiGenerateBtn.disabled = false;

    if (result.success) {
      aiPreviewTextEl.textContent = result.message;
      aiPreviewEl.classList.add('show');
    } else {
      showTestResult(i18n.t('ai.aiError') + ' ' + result.error, 'error');
    }
  } catch (e) {
    aiGeneratingEl.style.display = 'none';
    testAiGenerateBtn.disabled = false;
    showTestResult(i18n.t('ai.aiError') + ' ' + e.message, 'error');
  }
});

restoreMessageDraft();
loadAIConfig();
loadApiTransportStatus();
// DEBUG log - check values after loadAIConfig
renderSavedMessages();

// ========== I18N (Language Switch) ==========
const langViBtn = document.getElementById('langVi');
const langEnBtn = document.getElementById('langEn');

async function applyLanguage(lang) {
  i18n.lang = lang;
  chrome.storage.local.set({ appLang: lang }).catch(() => {
    try { localStorage.setItem('tinder_ext_appLang', JSON.stringify(lang)); } catch(e2) {}
  });

  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    el.textContent = i18n.t(key);
  });

  document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
    const key = el.getAttribute('data-i18n-placeholder');
    el.placeholder = i18n.t(key);
  });

  langViBtn.classList.toggle('active', lang === 'vi');
  langEnBtn.classList.toggle('active', lang === 'en');

  if (systemPromptInput) {
    const p = i18n.prompts[lang];
    // Only set defaults if no saved prompt exists (avoid overwriting values already loaded from storage)
    const hasSys = systemPromptInput.value.trim() !== '';
    const hasUsr = userPromptInput.value.trim() !== '';
    if (!hasSys) systemPromptInput.value = p.system;
    if (!hasUsr) userPromptInput.value = p.user;
  }

  const savedEmpty = document.querySelector('.saved-empty');
  if (savedEmpty) savedEmpty.textContent = i18n.t('msg.savedEmpty');
}

async function switchToLang(lang) {
  await applyLanguage(lang);
}

if (langViBtn) langViBtn.addEventListener('click', () => switchToLang('vi'));
if (langEnBtn) langEnBtn.addEventListener('click', () => switchToLang('en'));

// Init language — load from storage or default to Vietnamese
(async () => {
  try {
    const result = await chrome.storage.local.get(['appLang']);
    const savedLang = result.appLang || 'vi';
    applyLanguage(savedLang);
  } catch (e) {
    try {
      const raw = localStorage.getItem('tinder_ext_appLang');
      const savedLang = raw ? JSON.parse(raw) : 'vi';
      applyLanguage(savedLang);
    } catch (e2) {
      applyLanguage('vi');
    }
  }
})();
